# 🔍 Code Review Report

## Summary

| Metric | Value |
|--------|-------|
| **Overall Score** | 25/100 |
| **Files Reviewed** | 1 |
| **Critical Issues** | 3 |
| **High Priority Tests** | 7 |
| **Refactoring Opportunities** | 3 |

## 🎯 Top Recommendations

1. 🚨 **security**: REJECT PR until all three search functions are rewritten using parameterized queries. All functions (searchTodos, searchTodosByStatus, getTodosByUser) contain SQL injection vulnerabilities via string interpolation/concatenation. Use $1, $2 placeholders as demonstrated in createTodo (line 58) and getTodoById (line 80). This is the most severe issue and prevents merge.
   - Files: src/todo.ts

2. 🚨 **testing**: Add comprehensive test suite for all three new functions with focus on security. Must include: SQL injection attempts (e.g., `' OR '1'='1`, `1 OR 1=1 --`), empty input handling, parameter validation, database error handling, and cross-user data access prevention in getTodosByUser. Minimum 15-20 tests required. Current test coverage is 0% for these functions.
   - Files: src/todo.ts, src/todo.test.ts

3. 🚨 **security**: Change searchTodosByStatus parameter type from string to boolean to match the data type in the todos table and improve type safety. Update function signature: `searchTodosByStatus(completed: boolean): Promise<Todo[]>`
   - Files: src/todo.ts

4. ⚠️ **security**: Add input validation to searchTodos and getTodosByUser functions. Check for empty/null values, enforce length limits (similar to validateTodoInput), and trim whitespace before querying. Prevents DoS attacks and invalid query states.
   - Files: src/todo.ts

5. ⚠️ **best-practice**: Add ORDER BY clause to searchTodos and getTodosByUser for consistent result ordering. Use `ORDER BY created_at DESC` to match getAllTodos pattern and provide predictable, deterministic results to callers.
   - Files: src/todo.ts

## 📁 File Details

### 📄 `src/todo.ts`

**Quality Score:** 25/100 | **Coverage:** ~20%

#### Issues (8)
  - Line 115: `critical` SQL injection vulnerability via string interpolation. The keyword parameter is directly embedded in the SQL query using template literals. An attacker can inject malicious SQL such as `' OR '1'='1` to bypass query logic, extract unauthorized data, or modify/delete data. The file already demonstrates proper parameterized query patterns in createTodo() (line 58) and getTodoById() (line 80) that should be followed here.
  - Line 125: `critical` SQL injection vulnerability via string concatenation. The completed parameter is directly concatenated without any validation, quotes, or parameterization. An attacker could inject SQL fragments like `1 OR 1=1 --` to return all records or perform database attacks. This is especially dangerous as boolean/status values are often trusted without validation.
  - Line 133: `critical` SQL injection vulnerability via template literal string interpolation. The userId parameter is directly embedded in the SQL query without sanitization or parameterization. An attacker can inject SQL to escalate privileges, access other users' todos, or corrupt the database. The existing getTodoById() function (line 80) demonstrates the correct secure pattern using $1 placeholder.

  *...and 5 more*

#### Test Gaps (10)
  - `searchTodos` (critical priority)
  - `searchTodos - special characters SQL injection` (critical priority)

  *...and 8 more*

#### Refactoring Opportunities (3)
  - **pattern-improvement**: Critical security vulnerability: All three search functions use string concatenation or template literals instead of parameterized queries. This violates the secure pattern already established in the file (createTodo, getTodoById, updateTodoStatus, deleteTodo all use parameterized queries with $1, $2, etc.). This creates SQL injection vulnerabilities. Additionally, searchTodosByStatus lacks proper type safety and searchTodos lacks input validation applied elsewhere.
  - **simplify**: Parameter type mismatch: function accepts string but todos.completed column is boolean. Should accept boolean parameter for type safety and to align with SQL query semantics. Current string parameter only exists because of vulnerable string concatenation.

  *...and 1 more*

---

*Generated at 2026-11-24T10:11:35.764Z • Duration: 196464ms*
