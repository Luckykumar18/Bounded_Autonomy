import * as dotenv from 'dotenv';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { CodeReviewOrchestrator } from './orchestrator.js';
import { ReportGenerator, logger } from './utils/index.js';
import { logReviewStart } from './utils/logger.js';
 
// Load environment variables
dotenv.config();
 
/** Prints an error message and exits without a stack trace */
function exitWithError(message: string): never {
  console.error(`\n❌ ${message}\n`);
  process.exit(1);
}
 
/** Validates the three command-line arguments */
function validateArguments(
  owner: string | undefined,
  repo: string | undefined,
  prStr: string | undefined
): { owner: string; repo: string; prNumber: number } {
  if (!owner || !repo || !prStr) {
    exitWithError(
      'Missing arguments.\n' +
        '   Usage:   npm run dev -- <owner> <repo> <pr-number>\n' +
        '   Example: npm run dev -- udacity cd14715-simple-todo-app 1'
    );
  }
 
  const prNumber = Number(prStr);
  if (!Number.isInteger(prNumber) || prNumber <= 0) {
    exitWithError(`Invalid PR number "${prStr}". It must be a positive whole number, e.g. 1.`);
  }
 
  return { owner, repo, prNumber };
}
 
/** Validates that either Anthropic API or AWS Bedrock credentials exist */
function validateAuthentication(): void {
  const hasAnthropicKey = Boolean(process.env.ANTHROPIC_API_KEY);
  const hasAwsKeys = Boolean(process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY);
 
  if (hasAnthropicKey) {
    console.log('🔐 Using Anthropic API authentication');
    return;
  }
 
  if (hasAwsKeys) {
    if (!process.env.AWS_REGION) {
      exitWithError('AWS credentials found but AWS_REGION is not set.\n   Add AWS_REGION=us-east-1 (or your region) to .env');
    }
    console.log('🔐 Using AWS Bedrock authentication');
    return;
  }
 
  exitWithError(
    'No authentication configured. Set ONE of these options:\n' +
      '   Option 1 (Anthropic API): ANTHROPIC_API_KEY=sk-ant-...\n' +
      '   Option 2 (AWS Bedrock):   AWS_ACCESS_KEY_ID=..., AWS_SECRET_ACCESS_KEY=..., AWS_REGION=us-east-1'
  );
}
 
/** Validates that ANTHROPIC_MODEL is set */
function validateModel(): string {
  const model = process.env.ANTHROPIC_MODEL;
  if (!model) {
    exitWithError(
      'ANTHROPIC_MODEL is not set. Add it to .env:\n' +
        '   Anthropic API: ANTHROPIC_MODEL=claude-sonnet-4-5-20250929\n' +
        '   AWS Bedrock:   ANTHROPIC_MODEL=us.anthropic.claude-sonnet-4-5-20250929-v1:0'
    );
  }
  return model;
}
 
/** Turns any error into a short, actionable message */
function friendlyErrorMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error);
  const lower = message.toLowerCase();
 
  if (lower.includes('401') || lower.includes('authentication') || lower.includes('api key')) {
    return `Authentication failed. Check your API key or AWS credentials.\n   Details: ${message}`;
  }
  if (lower.includes('404') || lower.includes('not found')) {
    return `Pull request not found. Check the owner, repo and PR number.\n   Details: ${message}`;
  }
  if (lower.includes('rate limit') || lower.includes('429')) {
    return `Rate limit reached. Wait a minute and try again, or set GITHUB_TOKEN in .env.\n   Details: ${message}`;
  }
  if (lower.includes('timeout') || lower.includes('timed out')) {
    return `The review timed out. Try again, or review a smaller PR.\n   Details: ${message}`;
  }
  return `Review failed: ${message}`;
}
 
/**
 * Main entry point for the Claude Multi-Agent Code Review System
 * Usage: npm run dev <owner> <repo> <pr-number>
 */
async function main(): Promise<void> {
  const [ownerArg, repoArg, prArg] = process.argv.slice(2);
 
  // 1. Validate arguments, authentication and model
  const { owner, repo, prNumber } = validateArguments(ownerArg, repoArg, prArg);
  validateAuthentication();
  const model = validateModel();
 
  if (!process.env.GITHUB_TOKEN) {
    console.warn('⚠️  GITHUB_TOKEN not set: GitHub API rate limits will be lower.');
  }
 
  console.log(`🤖 Model: ${model}`);
  logReviewStart(owner, repo, prNumber);
 
  try {
    // 2. Run the review
    const orchestrator = new CodeReviewOrchestrator({ model });
    const report = await orchestrator.reviewPullRequest(owner, repo, prNumber);
 
    // 3. Generate all three report formats
    const generator = new ReportGenerator();
    const reportsDir = path.join(process.cwd(), 'reports');
    await mkdir(reportsDir, { recursive: true });
 
    const baseName = `${owner}-${repo}-pr${prNumber}`;
    const outputs = [
      { file: `${baseName}.md`, content: generator.generateMarkdownReport(report) },
      { file: `${baseName}.html`, content: generator.generateHTMLReport(report) },
      { file: `${baseName}.json`, content: generator.generateJSONReport(report) },
    ];
 
    for (const output of outputs) {
      const filePath = path.join(reportsDir, output.file);
      await writeFile(filePath, output.content, 'utf-8');
      console.log(`✅ Saved ${path.relative(process.cwd(), filePath)}`);
    }
 
    // 4. Summary
    const { summary } = report;
    console.log('\n📊 Review complete');
    console.log(`   Files reviewed:            ${summary.totalFiles}`);
    console.log(`   Overall score:             ${summary.overallScore}/100`);
    console.log(`   Critical issues:           ${summary.criticalIssues}`);
    console.log(`   High-priority test gaps:   ${summary.highPriorityTests}`);
    console.log(`   Refactoring opportunities: ${summary.refactoringOpportunities}`);
    console.log(`   Duration:                  ${(report.metadata.duration / 1000).toFixed(1)}s\n`);
  } catch (error) {
    logger.error('Review failed', { error: error instanceof Error ? error.message : String(error) });
    exitWithError(friendlyErrorMessage(error));
  }
}
 
main().catch((error: unknown) => {
  exitWithError(friendlyErrorMessage(error));
});
 