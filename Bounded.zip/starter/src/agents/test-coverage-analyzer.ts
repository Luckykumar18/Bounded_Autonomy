import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { TEST_COVERAGE_ANALYZER_PROMPT } from '../prompts/test-coverage-analyzer.prompt.js';
 
export const testCoverageAnalyzer: AgentDefinition = {
  description:
    'Evaluates test completeness by comparing changed source files with their test files, finds untested functions and missing assertions, and suggests specific test cases. Use this agent for any test-coverage review of PR files.',
  prompt: TEST_COVERAGE_ANALYZER_PROMPT,
  tools: ['Read', 'Grep', 'Glob', 'mcp__github__get_file_contents'],
  model: 'inherit',
};