import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { CODE_QUALITY_ANALYZER_PROMPT } from '../prompts/code-quality-analyzer.prompt.js';
 
export const codeQualityAnalyzer: AgentDefinition = {
  description:
    'Analyzes code changes for security vulnerabilities, performance issues, and maintainability concerns. Use this agent for any security, performance, or code-quality review of PR files.',
  prompt: CODE_QUALITY_ANALYZER_PROMPT,
  tools: ['Read', 'Grep', 'Glob', 'Skill', 'mcp__github__get_file_contents'],
  model: 'inherit',
};