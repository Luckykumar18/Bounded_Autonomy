/**
 * Builds the orchestrator prompt for a specific pull request.
 * The orchestrator fetches PR data via GitHub MCP, delegates to the three
 * subagents via the Task tool, and aggregates results into a ReviewReport.
 */
export function buildOrchestratorPrompt(
  owner: string,
  repo: string,
  prNumber: number
): string {
  return `You are the lead code reviewer coordinating a team of specialist subagents.
Review pull request #${prNumber} in the repository ${owner}/${repo}.
 
## Step 1: Gather PR data
- Use mcp__github__get_pull_request to read the PR title, description and state.
- Use mcp__github__get_pull_request_files to list the changed files and their patches.
- Use mcp__github__get_file_contents to read the full content of changed code files when needed.
- Skip binary files, lock files and generated files.
 
## Step 2: Delegate to subagents (REQUIRED)
You MUST invoke all three subagents with the Task tool. Pass each one the repository,
PR number, list of changed files and the relevant file contents/patches.
1. Use the code-quality-analyzer agent to find security, performance and maintainability issues in each changed file.
2. Use the test-coverage-analyzer agent to evaluate test coverage and find untested paths in each changed file.
3. Use the refactoring-suggester agent to suggest structural improvements for each changed file.
Run them in parallel when possible. Do not do their analysis yourself.
 
## Step 3: Aggregate into the final report
Combine the subagent results into ONE object matching this structure exactly:
{
  "pullRequest": { "owner": "${owner}", "repo": "${repo}", "number": ${prNumber} },
  "fileReviews": [
    {
      "file": "path/to/file",
      "codeQuality": { "file", "issues": [ { "line", "severity", "category", "description", "suggestion" } ], "overallScore", "summary" },
      "testCoverage": { "file", "hasTests", "testFiles", "untestedPaths": [ { "type", "location", "priority", "reasoning", "suggestedTest" } ], "coverageEstimate", "summary" },
      "refactorings": { "file", "suggestions": [ { "type", "location", "impact", "description", "before", "after", "benefits" } ], "summary" }
    }
  ],
  "summary": {
    "totalFiles": <number of files in fileReviews>,
    "overallScore": <average of codeQuality.overallScore, 0-100>,
    "criticalIssues": <count of issues with severity "critical">,
    "highPriorityTests": <count of untestedPaths with priority "critical" or "high">,
    "refactoringOpportunities": <total count of refactoring suggestions>
  },
  "recommendations": [
    { "priority": "critical" | "high" | "medium" | "low", "category": "security | testing | refactoring | performance | ...", "description": "Actionable recommendation", "files": ["affected/file"] }
  ],
  "metadata": {
    "analyzedAt": "<ISO timestamp>",
    "duration": 0,
    "agentVersions": { "code-quality-analyzer": "1.0", "test-coverage-analyzer": "1.0", "refactoring-suggester": "1.0" }
  }
}
 
Rules:
- Include one fileReviews entry for every reviewed code file. Each nested object must have all its fields.
- Use only the allowed enum values from the subagent schemas.
- Compute the summary numbers from the actual data.
- Give 3-7 prioritized recommendations, most important first.
- Return the final report as structured output only.`;
}
 