import { query } from '@anthropic-ai/claude-agent-sdk';
import type { SDKMessage } from '@anthropic-ai/claude-agent-sdk';
import { ReviewReportSchema, ReviewReportJSONSchema } from './types/report-types.js';
import type { ReviewReport } from './types/report-types.js';
import { codeQualityAnalyzer, testCoverageAnalyzer, refactoringSuggester } from './agents/index.js';
import { buildOrchestratorPrompt } from './prompts/index.js';
import { mcpServersConfig } from './config/mcp.config.js';
 
/**
 * Orchestrator configuration options
 */
export interface OrchestratorOptions {
  /** Model to use (defaults to ANTHROPIC_MODEL) */
  model?: string;
  /** Maximum conversation turns before stopping */
  maxTurns?: number;
  /** Project root containing .claude/skills (defaults to PROJECT_ROOT) */
  projectRoot?: string;
  /** Print tool usage while running */
  verbose?: boolean;
}
 
/**
 * Main Code Review Orchestrator
 * Coordinates subagents to analyze pull requests and generate comprehensive reports
 */
export class CodeReviewOrchestrator {
  private readonly model: string | undefined;
  private readonly maxTurns: number;
  private readonly projectRoot: string;
  private readonly verbose: boolean;
 
  constructor(options: OrchestratorOptions = {}) {
    this.model = options.model ?? process.env.ANTHROPIC_MODEL;
    this.maxTurns = options.maxTurns ?? 50;
    this.projectRoot = options.projectRoot ?? process.env.PROJECT_ROOT ?? process.cwd();
    this.verbose = options.verbose ?? true;
  }
 
  /**
   * Review a pull request using parallel subagent analysis
   * @param owner - Repository owner
   * @param repo - Repository name
   * @param prNumber - Pull request number
   * @returns Complete review report
   */
  async reviewPullRequest(
    owner: string,
    repo: string,
    prNumber: number
  ): Promise<ReviewReport> {
    const startTime = Date.now();
    let structuredOutput: unknown;
    let resultText: string | undefined;
 
    const stream = query({
      prompt: buildOrchestratorPrompt(owner, repo, prNumber),
      options: {
        model: this.model,
        cwd: this.projectRoot,
        settingSources: ['project'], // loads .claude/skills so the Skill tool works
        maxTurns: this.maxTurns,
        permissionMode: 'bypassPermissions',
        mcpServers: mcpServersConfig,
        agents: {
          'code-quality-analyzer': codeQualityAnalyzer,
          'test-coverage-analyzer': testCoverageAnalyzer,
          'refactoring-suggester': refactoringSuggester,
        },
        allowedTools: [
          'Task',
          'Read',
          'Grep',
          'Glob',
          'Skill',
          'mcp__github__get_pull_request',
          'mcp__github__get_pull_request_files',
          'mcp__github__get_file_contents',
          'mcp__eslint__lint-files',
        ],
        outputFormat: {
          type: 'json_schema',
          schema: ReviewReportJSONSchema,
        },
      },
    });
 
    for await (const message of stream) {
      this.logMessage(message);
 
      if (message.type === 'result') {
        if (message.subtype !== 'success') {
          throw new Error(`Review did not complete (${message.subtype}). Try again or increase maxTurns.`);
        }
        structuredOutput = (message as { structured_output?: unknown }).structured_output;
        resultText = message.result;
      }
    }
 
    // Fallback: parse the text result if no structured output was returned
    if (structuredOutput === undefined && resultText) {
      structuredOutput = this.extractJson(resultText);
    }
    if (structuredOutput === undefined) {
      throw new Error('The orchestrator returned no report data.');
    }
 
    const parsed = ReviewReportSchema.safeParse(structuredOutput);
    if (!parsed.success) {
      const problems = parsed.error.issues
        .slice(0, 5)
        .map((issue) => `${issue.path.join('.')}: ${issue.message}`)
        .join('; ');
      throw new Error(`Report failed schema validation: ${problems}`);
    }
 
    // Fill in reliable values from code rather than trusting the model
    return {
      ...parsed.data,
      pullRequest: { owner, repo, number: prNumber },
      metadata: {
        ...parsed.data.metadata,
        analyzedAt: new Date().toISOString(),
        duration: Date.now() - startTime,
      },
    };
  }
 
  /** Logs MCP connection status and every tool call (shows Task/subagent usage) */
  private logMessage(message: SDKMessage): void {
    if (!this.verbose) return;
 
    if (message.type === 'system' && message.subtype === 'init') {
      for (const server of message.mcp_servers) {
        console.log(`🔌 MCP server ${server.name}: ${server.status}`);
      }
    }
 
    if (message.type === 'assistant') {
      for (const block of message.message.content) {
        if (block.type === 'tool_use') {
          if (block.name === 'Task') {
            const input = block.input as { subagent_type?: string; description?: string };
            console.log(`🤖 Task → ${input.subagent_type ?? 'subagent'}: ${input.description ?? ''}`);
          } else {
            console.log(`🔧 Tool: ${block.name}`);
          }
        }
      }
    }
  }
 
  /** Extracts a JSON object from text, handling ```json fences */
  private extractJson(text: string): unknown {
    const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    const candidate = fenced?.[1] ?? text;
    const start = candidate.indexOf('{');
    const end = candidate.lastIndexOf('}');
    if (start === -1 || end === -1) return undefined;
    try {
      return JSON.parse(candidate.slice(start, end + 1));
    } catch {
      return undefined;
    }
  }
}
 