import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { REFACTORING_SUGGESTER_PROMPT } from '../prompts/refactoring-suggester.prompt.js';
 
export const refactoringSuggester: AgentDefinition = {
  description:
    'Identifies refactoring opportunities in changed code: modernizing old patterns, applying design patterns, reducing duplication, and improving clarity. Use this agent for structural improvement suggestions on PR files.',
  prompt: REFACTORING_SUGGESTER_PROMPT,
  tools: ['Read', 'Grep', 'Glob', 'Skill', 'mcp__github__get_file_contents'],
  model: 'inherit',
};