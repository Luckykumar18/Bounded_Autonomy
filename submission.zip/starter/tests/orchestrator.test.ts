import { describe, it, expect, vi, beforeEach } from 'vitest';
 
// Replace the real SDK with a fake so tests never call the API
vi.mock('@anthropic-ai/claude-agent-sdk', () => ({ query: vi.fn() }));
 
import { query } from '@anthropic-ai/claude-agent-sdk';
import { CodeReviewOrchestrator } from '../src/orchestrator.js';
import { RateLimiter, DEFAULT_RATE_LIMITS } from '../src/utils/rate-limiter.js';
import { ReviewReportSchema } from '../src/types/report-types.js';
 
/**
* Tests for CodeReviewOrchestrator
* The SDK is mocked, so no API keys or network are needed.
*/
 
// A small, schema-valid report used as the fake model output
const validReport = {
  pullRequest: { owner: 'octocat', repo: 'Hello-World', number: 1 },
  fileReviews: [
    {
      file: 'README',
      codeQuality: { file: 'README', issues: [], overallScore: 90, summary: 'Clean file' },
      testCoverage: {
        file: 'README',
        hasTests: false,
        testFiles: [],
        untestedPaths: [],
        coverageEstimate: 0,
        summary: 'Documentation only',
      },
      refactorings: { file: 'README', suggestions: [], summary: 'Nothing to refactor' },
    },
  ],
  summary: {
    totalFiles: 1,
    overallScore: 90,
    criticalIssues: 0,
    highPriorityTests: 0,
    refactoringOpportunities: 0,
  },
  recommendations: [],
  metadata: {
    analyzedAt: new Date().toISOString(),
    duration: 0,
    agentVersions: {
      'code-quality-analyzer': '1.0',
      'test-coverage-analyzer': '1.0',
      'refactoring-suggester': '1.0',
    },
  },
};
 
/** Makes the mocked query() stream the given messages */
function mockQueryMessages(messages: unknown[]) {
  vi.mocked(query).mockImplementation((() =>
    (async function* () {
      for (const m of messages) yield m;
    })()) as never);
}
 
/** Returns the options object the orchestrator passed to query() */
function lastQueryOptions(): Record<string, any> {
  const call = vi.mocked(query).mock.calls.at(-1);
  return (call?.[0] as { options: Record<string, any> }).options;
}
 
const successResult = {
  type: 'result',
  subtype: 'success',
  result: '',
  structured_output: validReport,
};
 
describe('CodeReviewOrchestrator', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.ANTHROPIC_MODEL = 'test-model';
  });
 
  describe('Configuration', () => {
    it('should initialize with default options', async () => {
      mockQueryMessages([successResult]);
      const orchestrator = new CodeReviewOrchestrator({ verbose: false });
      await orchestrator.reviewPullRequest('octocat', 'Hello-World', 1);
 
      const options = lastQueryOptions();
      expect(options.model).toBe('test-model'); // from ANTHROPIC_MODEL
      expect(options.maxTurns).toBe(50);
      expect(options.permissionMode).toBe('bypassPermissions');
    });
 
    it('should accept custom rate limit configuration', () => {
      const limiter = new RateLimiter({ maxRequestsPerMinute: 10, maxConcurrent: 2 });
      const status = limiter.getStatus();
 
      expect(status.availableRequests).toBe(10); // custom value applied
      expect(status.availableTokens).toBe(DEFAULT_RATE_LIMITS.maxTokensPerMinute); // default kept
      expect(status.activeRequests).toBe(0);
    });
  });
 
  describe('reviewPullRequest', () => {
    it('should fetch PR files from GitHub MCP', async () => {
      mockQueryMessages([successResult]);
      await new CodeReviewOrchestrator({ verbose: false }).reviewPullRequest('octocat', 'Hello-World', 1);
 
      const options = lastQueryOptions();
      expect(options.mcpServers).toHaveProperty('github');
      expect(options.allowedTools).toContain('mcp__github__get_pull_request');
      expect(options.allowedTools).toContain('mcp__github__get_pull_request_files');
 
      const prompt = (vi.mocked(query).mock.calls[0]?.[0] as { prompt: string }).prompt;
      expect(prompt).toContain('octocat/Hello-World');
    });
 
    it('should spawn all 3 subagents in parallel', async () => {
      mockQueryMessages([successResult]);
      await new CodeReviewOrchestrator({ verbose: false }).reviewPullRequest('octocat', 'Hello-World', 1);
 
      const options = lastQueryOptions();
      expect(Object.keys(options.agents)).toEqual([
        'code-quality-analyzer',
        'test-coverage-analyzer',
        'refactoring-suggester',
      ]);
      expect(options.allowedTools).toContain('Task'); // required to invoke subagents
      for(const agent of Object.values(options.agents) as { tools: string[] }[]){
        expect(agent.tools).toContain('Skill');
      }
    });
 
    it('should aggregate results into ReviewReport', async () => {
      mockQueryMessages([successResult]);
      const report = await new CodeReviewOrchestrator({ verbose: false }).reviewPullRequest(
        'octocat',
        'Hello-World',
        1
      );
 
      expect(report.pullRequest).toEqual({ owner: 'octocat', repo: 'Hello-World', number: 1 });
      expect(report.fileReviews).toHaveLength(1);
      expect(report.summary.totalFiles).toBe(1);
      expect(report.metadata.duration).toBeGreaterThanOrEqual(0);
      expect(ReviewReportSchema.safeParse(report).success).toBe(true);
    });
 
    it('should validate output with Zod schema', async () => {
      mockQueryMessages([
        { type: 'result', subtype: 'success', result: '', structured_output: { wrong: 'shape' } },
      ]);
 
      await expect(
        new CodeReviewOrchestrator({ verbose: false }).reviewPullRequest('octocat', 'Hello-World', 1)
      ).rejects.toThrow(/schema validation/);
    });
 
    it('should fail clearly when the review does not complete', async () => {
      mockQueryMessages([{ type: 'result', subtype: 'error_max_turns' }]);
 
      await expect(
        new CodeReviewOrchestrator({ verbose: false }).reviewPullRequest('octocat', 'Hello-World', 1)
      ).rejects.toThrow(/did not complete/);
    });
 
    it('should fall back to parsing JSON from the text result', async () => {
      mockQueryMessages([
        {
          type: 'result',
          subtype: 'success',
          result: '```json\n' + JSON.stringify(validReport) + '\n```',
        },
      ]);
 
      const report = await new CodeReviewOrchestrator({ verbose: false }).reviewPullRequest(
        'octocat',
        'Hello-World',
        1
      );
      expect(report.summary.overallScore).toBe(90);
    });
  });
 
  describe('Integration', () => {
    // These tests require actual API keys and should be skipped in CI
    it.skip('should review a real small PR', async () => {
      // NOTE: Only run manually with valid API keys (remove .skip)
      vi.doUnmock('@anthropic-ai/claude-agent-sdk');
      const report = await new CodeReviewOrchestrator().reviewPullRequest('octocat', 'Hello-World', 1);
      expect(report.fileReviews.length).toBeGreaterThan(0);
    }, 300_000);
  });
});